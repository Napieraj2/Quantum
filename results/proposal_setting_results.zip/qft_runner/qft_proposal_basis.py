"""Scratch vectorized Eve sampler with proposal basis persistence.

The caller owns exchange order.  To reproduce the archived model, loop
attempt -> block and call ``intercept_leg`` for the forward leg, apply Alice's
encoding, then call it for the return leg.  Reuse the same ``basis_state`` for
all calls.  Trials are vectorized; signal is the outer loop and the supplied
Eve tuple is the inner loop.
"""

import numpy as np


# Record codes: Z0, Z1, X0, X1; -1 means no retained record.
EIGENSTATES = np.array(
    [[1, 0], [0, 1], [1, 1], [1, -1]], dtype=complex
)
EIGENSTATES[2:] /= np.sqrt(2)


def _probability_vector(values, size, name):
    values = np.asarray(values, dtype=float)
    if values.ndim == 0:
        values = np.full(size, values)
    if values.shape != (size,) or np.any((values < 0) | (values > 1)):
        raise ValueError(f"{name} must be a probability scalar or length-{size} vector")
    return values


def init_basis_state(rng, trials, eve_z_probabilities):
    """Draw each trial/Eve's basis from its stationary Bernoulli law.

    Basis code 0 is Z and 1 is X.  The result must be reused and is mutated by
    ``intercept_leg``.
    """
    p_z = np.asarray(eve_z_probabilities, dtype=float)
    if trials < 1 or p_z.ndim != 1 or np.any((p_z < 0) | (p_z > 1)):
        raise ValueError("trials must be positive and Eve Z probabilities valid")
    return (rng.random((trials, len(p_z))) >= p_z).astype(np.int8)


def intercept_leg(
    states,
    rng,
    interception_rates,
    eve_z_probabilities,
    redraw_probability,
    basis_state,
    *,
    keep_first,
):
    """Apply sequential Eves to one block/leg and retain first/last records.

    Parameters
    ----------
    states : complex array, shape (trials, signals, 2)
        Local pure states, mutated in place.
    interception_rates : array-like, shape (trials,)
        Current per-trial interception probabilities.
    eve_z_probabilities : sequence, shape (eves,)
        Eve tuple order is the physical sequential order.
    redraw_probability : scalar or sequence, shape (eves,)
        After every passing signal, each trial/Eve redraws with this chance,
        whether or not it intercepted.
    basis_state : int8 array, shape (trials, eves)
        Persistent 0=Z/1=X state, mutated in place.
    keep_first : bool
        True retains the first Eve record per signal (return leg); False
        retains the last (forward leg).  Every Eve measurement still acts.
    """
    states = np.asarray(states)
    if states.ndim != 3 or states.shape[-1] != 2:
        raise ValueError("states must have shape (trials, signals, 2)")
    trials, signals, _ = states.shape
    rates = _probability_vector(interception_rates, trials, "interception_rates")
    p_z = np.asarray(eve_z_probabilities, dtype=float)
    if p_z.ndim != 1 or np.any((p_z < 0) | (p_z > 1)):
        raise ValueError("eve_z_probabilities must be a probability vector")
    redraw = _probability_vector(
        redraw_probability, len(p_z), "redraw_probability"
    )
    if basis_state.shape != (trials, len(p_z)):
        raise ValueError("basis_state must have shape (trials, eves)")

    records = np.full((trials, signals), -1, dtype=np.int8)
    for signal in range(signals):
        for eve, (eve_p_z, eve_redraw) in enumerate(zip(p_z, redraw)):
            hit = rng.random(trials) < rates
            if np.any(hit):
                basis = basis_state[hit, eve]
                measured = states[hit, signal]
                p_zero = np.where(
                    basis == 1,
                    abs(measured.sum(axis=1)) ** 2 / 2,
                    abs(measured[:, 0]) ** 2,
                ).clip(0, 1)
                outcome = rng.random(hit.sum()) >= p_zero
                codes = (2 * basis + outcome).astype(np.int8)
                states[hit, signal] = EIGENSTATES[codes]
                if keep_first:
                    current = records[hit, signal]
                    records[hit, signal] = np.where(
                        current == -1, codes, current
                    )
                else:
                    records[hit, signal] = codes

            # Archive order: current basis is used above, then a passing
            # signal may redraw even when this Eve did not intercept.
            redraw_now = rng.random(trials) < eve_redraw
            if np.any(redraw_now):
                basis_state[redraw_now, eve] = (
                    rng.random(redraw_now.sum()) >= eve_p_z
                ).astype(np.int8)
    return records


def _self_test():
    trials = 40_000
    p_z = np.array([0.1, 0.9])
    states = np.tile(
        np.array([1, 1], dtype=complex) / np.sqrt(2),
        (trials, 1, 1),
    )

    # Initialization is stationary, and one redraw step keeps that marginal.
    rng = np.random.default_rng(7)
    basis = init_basis_state(rng, trials, p_z)
    before = 1 - basis.mean(axis=0)
    intercept_leg(
        states.copy(), rng, np.zeros(trials), p_z, 0.1, basis,
        keep_first=False,
    )
    after = 1 - basis.mean(axis=0)
    assert np.all(abs(before - p_z) < 0.01)
    assert np.all(abs(after - p_z) < 0.01)

    # λ=.1 retains strong memory; λ=1 leaves only stationary coincidence.
    rng = np.random.default_rng(11)
    persistent = init_basis_state(rng, trials, p_z)
    old = persistent.copy()
    intercept_leg(
        states.copy(), rng, np.zeros(trials), p_z, 0.1, persistent,
        keep_first=False,
    )
    agreement_persistent = (persistent == old).mean()

    rng = np.random.default_rng(11)
    independent = init_basis_state(rng, trials, p_z)
    old = independent.copy()
    intercept_leg(
        states.copy(), rng, np.zeros(trials), p_z, 1.0, independent,
        keep_first=False,
    )
    agreement_independent = (independent == old).mean()
    assert agreement_persistent > agreement_independent + 0.05
    print(
        "PASS",
        {"stationary_p_z": after.tolist(),
         "same_basis_lambda_0.1": agreement_persistent,
         "same_basis_lambda_1": agreement_independent},
    )


if __name__ == "__main__":
    _self_test()
