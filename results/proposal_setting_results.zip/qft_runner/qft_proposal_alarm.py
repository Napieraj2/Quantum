"""QFT proposal sweep scoring frozen from the original run.

Source: quantum_study/qft_study.py at 35b7979171855076ad747a710bd88e98904fafd1.
"""

from dataclasses import dataclass

import numpy as np

from qft_proposal_exchange import RECOVERY_CONFIDENCE


DETECTORS = ("Pooled check errors", "Joint-check surprisal")
TARGET_FALSE_ALARM = 0.05


@dataclass(frozen=True)
class _AlarmRule:
    looks: np.ndarray
    centers: np.ndarray
    scales: np.ndarray
    cutoff: float
    tie_probability: float


def _standardize(values, centers, scales):
    delta = values - centers
    scores = np.zeros_like(delta, dtype=float)
    np.divide(delta, scales, out=scores, where=scales > 0)
    scores[(scales == 0) & (delta > 0)] = np.inf
    scores[(scales == 0) & (delta < 0)] = -np.inf
    return scores


def _fit_alarm_rule(values, looks, target=TARGET_FALSE_ALARM):
    selected = values[:, looks - 1]
    centers = selected.mean(axis=0)
    scales = selected.std(axis=0)
    maxima = _standardize(selected, centers, scales).max(axis=1)
    rank = int(np.ceil((1 - target) * len(maxima))) - 1
    cutoff = float(np.partition(maxima, rank)[rank])
    above = np.mean(maxima > cutoff)
    tied = np.mean(maxima == cutoff)
    tie_probability = float(np.clip((target - above) / tied, 0.0, 1.0))
    return _AlarmRule(looks, centers, scales, cutoff, tie_probability)


def _first_alarms(values, rule, tie_draws):
    scores = _standardize(
        values[:, rule.looks - 1], rule.centers, rule.scales
    )
    alarms = (scores > rule.cutoff) | (
        (scores == rule.cutoff)
        & (tie_draws[:, None] < rule.tie_probability)
    )
    has_alarm = alarms.any(axis=1)
    first = np.argmax(alarms, axis=1)
    return np.where(has_alarm, rule.looks[first], values.shape[1] + 1)


def _declarations(paths, attempts):
    posterior = np.asarray(paths["posterior"])
    confidence = posterior.max(axis=2)
    guesses = posterior.argmax(axis=2)
    reached = confidence >= RECOVERY_CONFIDENCE
    has_declaration = reached.any(axis=1)
    first = np.argmax(reached, axis=1)
    declaration_attempt = np.where(has_declaration, first + 1, attempts + 1)
    declaration_guess = guesses[np.arange(len(guesses)), first]
    return declaration_attempt, declaration_guess
