"""Scratch QFT exchange for the proposal's retained-check schedules.

This preserves the active exact phase marginal and attempt-level Eve posterior,
but returns Bob's errors and joint-pattern surprisal one retained check at a
time.  Check order is attempt, block, then increasing check-qubit position.
"""

import numpy as np
from scipy.special import logsumexp

from qft_proposal_basis import init_basis_state, intercept_leg as _persistent_intercept_leg


CHECKS_PER_ATTEMPT = 4
RECOVERY_CONFIDENCE = 0.99
_TINY = np.finfo(float).tiny
_NEAR_ONE = 1 - 16 * np.finfo(float).eps
# Codes 0/1 are Z outcomes, 2/3 are X outcomes, and -1 means no record.
_EIGENSTATES = np.array([[1, 0], [0, 1], [1, 1], [1, -1]], dtype=complex)
_EIGENSTATES[2:] /= np.sqrt(2)


def _bits(width):
    return (np.arange(2**width)[:, None] >> np.arange(width - 1, -1, -1)) & 1


def _rotations(qubits):
    dimension = 2**qubits
    weights = 2 ** np.arange(qubits - 1, -1, -1)
    return np.exp(2j * np.pi * np.outer(np.arange(dimension), weights) / dimension)


def _sample_paulis(states, rng, q_z, q_x):
    draws = rng.random(states.shape[:-1])
    flip = draws < q_z
    states[flip] = states[flip, ::-1]
    phase_flip = (draws >= q_z) & (draws < q_z + q_x)
    states[phase_flip, 1] *= -1


def _fresh_intercept_leg(states, rng, rate, eve_z_probabilities, keep_first):
    """Active-model fast path: redraw an independent basis on every hit."""
    records = np.full(states.shape[:-1], -1, dtype=np.int8)
    if not np.any(rate):
        return records
    for p_z in eve_z_probabilities:
        hit = rng.random(records.shape) < rate
        x_basis = rng.random(hit.sum()) >= p_z
        measured = states[hit]
        p_zero = np.where(
            x_basis,
            abs(measured.sum(axis=1)) ** 2 / 2,
            abs(measured[:, 0]) ** 2,
        )
        outcome = rng.random(len(p_zero)) >= p_zero.clip(0, 1)
        codes = 2 * x_basis + outcome
        states[hit] = _EIGENSTATES[codes]
        if keep_first:
            empty = records[hit] == -1
            records[hit] = np.where(empty, codes, records[hit])
        else:
            records[hit] = codes
    return records


def _null_decoding_probabilities(phases, candidates, rotations, q_z, q_x):
    """Average Bob's null outcome probabilities over unknown payload values."""
    coherence_scale = 1 - q_z - 2 * q_x
    coherence = phases / 2
    coherence = coherence_scale * coherence + q_z * coherence.conj()
    coherence = coherence[..., None, :] * rotations[candidates]
    coherence = coherence_scale * coherence + q_z * coherence.conj()
    coherence *= phases.conj()[..., None, :]
    probabilities = (
        0.5 + (coherence[..., None, :] * rotations.conj()).real
    ).prod(axis=-1)
    return probabilities.mean(axis=-2)


def _payload_likelihoods(encodings, last_forward, first_return, q_x):
    """Exact likelihoods up to a factor common to all candidate messages."""
    informative = (last_forward >= 2) & (first_return >= 2)
    sign = np.where(last_forward == first_return, 1, -1)
    paired = (1 + sign[..., None, :] * (1 - 2 * q_x) * encodings.real) / 2
    return np.where(informative[..., None, :], paired, 1).prod(axis=-1)


def _per_check_statistics(null, candidate_checks, observed, values):
    """Return check errors and conditional surprisal increments by check."""
    check_errors = observed != values
    prefix_match = np.ones(candidate_checks.shape[:-1], dtype=bool)
    previous_score = np.zeros(observed.shape[:-1])
    increments = np.empty(observed.shape, dtype=float)
    for check_index in range(observed.shape[-1]):
        prefix_match &= (
            candidate_checks[..., check_index]
            == observed[..., None, check_index]
        )
        prefix_probability = (null * prefix_match).sum(axis=-1)
        prefix_probability[prefix_probability >= _NEAR_ONE] = 1.0
        prefix_score = -np.log(np.maximum(prefix_probability, _TINY))
        increments[..., check_index] = prefix_score - previous_score
        previous_score = prefix_score
    return check_errors, increments


def simulate_paths(
    rng,
    *,
    trials,
    qubits,
    q_z,
    q_x,
    attempts,
    intercept_probability=0.0,
    eve_z_probabilities=(),
    redraw_probability=1.0,
    include_posterior=True,
):
    """Sample complete exchanges and return chronological per-check scores.

    Eve's posterior is updated once after all blocks in an attempt.  Her first
    99%-confidence declaration disables interception on later attempts, while
    Bob continues through ``attempts``.  A scalar ``redraw_probability=1``
    uses the active vectorized path exactly; persistent bases use the scratch
    helper and physical block order.
    """
    if not (q_z >= 0 and q_x >= 0 and q_z + q_x <= 1):
        raise ValueError("q_z and q_x must be nonnegative and sum to at most one")
    if qubits not in (2, 4):
        raise ValueError("qubits must be 2 or 4")
    if attempts < 1 or trials < 1:
        raise ValueError("attempts and trials must be positive")
    if not 0 <= intercept_probability <= 1:
        raise ValueError("intercept_probability must lie in [0, 1]")
    eve_z_probabilities = tuple(eve_z_probabilities)
    if any(not 0 <= probability <= 1 for probability in eve_z_probabilities):
        raise ValueError("eve_z_probabilities must lie in [0, 1]")
    redraw = np.asarray(redraw_probability, dtype=float)
    if np.any((redraw < 0) | (redraw > 1)):
        raise ValueError("redraw_probability must lie in [0, 1]")
    if redraw.ndim > 1 or (redraw.ndim == 1 and len(redraw) != len(eve_z_probabilities)):
        raise ValueError("redraw_probability must be scalar or one value per Eve")
    fresh_bases = redraw.ndim == 0 and float(redraw) == 1.0

    width = qubits // 2
    blocks = 4 // width
    rotations = _rotations(qubits)
    block_bits = _bits(qubits)
    payload_bits = _bits(width)
    secret_bits = _bits(4)
    weights = 2 ** np.arange(qubits - 1, -1, -1)
    payload_weights = 2 ** np.arange(width - 1, -1, -1)
    payload_index = secret_bits.reshape(16, blocks, width) @ payload_weights
    secret = rng.integers(16, size=trials)
    interception_rates = np.full(trials, intercept_probability, dtype=float)
    log_posterior = np.full((trials, 16), -np.log(16))
    if include_posterior:
        posterior = np.empty((trials, attempts, 16))
    retained_checks = attempts * CHECKS_PER_ATTEMPT
    errors = np.empty((trials, retained_checks), dtype=np.int8)
    scores = np.empty((trials, retained_checks))
    signal_shape = (trials, blocks, qubits)
    basis_state = None
    if not fresh_bases:
        basis_state = init_basis_state(rng, trials, eve_z_probabilities)

    for attempt in range(attempts):
        order = rng.random(signal_shape).argsort(axis=-1)
        checks = np.sort(order[..., :width], axis=-1)
        payload = np.sort(order[..., width:], axis=-1)
        values = rng.integers(2, size=checks.shape)
        check_message = (values * weights[checks]).sum(axis=-1)
        candidates = check_message[..., None] + weights[payload] @ payload_bits.T
        message = np.take_along_axis(
            candidates, payload_index[secret, :, None], axis=-1
        )[..., 0]

        phases = np.exp(1j * rng.uniform(0, 2 * np.pi, size=signal_shape))
        states = np.stack((np.ones_like(phases), phases), axis=-1) / np.sqrt(2)
        if fresh_bases:
            # Preserve the active λ=1 RNG order and output exactly.
            _sample_paulis(states, rng, q_z, q_x)
            forward = _fresh_intercept_leg(
                states,
                rng,
                interception_rates[:, None, None],
                eve_z_probabilities,
                keep_first=False,
            )
            states[..., 1] *= rotations[message]
            _sample_paulis(states, rng, q_z, q_x)
            returned = _fresh_intercept_leg(
                states,
                rng,
                interception_rates[:, None, None],
                eve_z_probabilities,
                keep_first=True,
            )
            states[..., 1] *= phases.conj()
        else:
            # Persistence is chronological: forward and return for one block,
            # then the next block, carrying the same per-trial Eve bases.
            forward = np.empty(signal_shape, dtype=np.int8)
            returned = np.empty(signal_shape, dtype=np.int8)
            for block in range(blocks):
                block_states = states[:, block]
                _sample_paulis(block_states, rng, q_z, q_x)
                forward[:, block] = _persistent_intercept_leg(
                    block_states,
                    rng,
                    interception_rates,
                    eve_z_probabilities,
                    redraw_probability,
                    basis_state,
                    keep_first=False,
                )
                block_states[..., 1] *= rotations[message[:, block]]
                _sample_paulis(block_states, rng, q_z, q_x)
                returned[:, block] = _persistent_intercept_leg(
                    block_states,
                    rng,
                    interception_rates,
                    eve_z_probabilities,
                    redraw_probability,
                    basis_state,
                    keep_first=True,
                )
                block_states[..., 1] *= phases[:, block].conj()

        amplitudes = (
            states[..., None, :, 0]
            + states[..., None, :, 1] * rotations.conj()
        )
        output_probabilities = (abs(amplitudes) ** 2 / 2).prod(axis=-1)
        cumulative = output_probabilities.cumsum(axis=-1)
        cumulative /= cumulative[..., -1:]
        outcomes = (rng.random((trials, blocks, 1)) > cumulative).sum(axis=-1)
        decoded_blocks = block_bits[outcomes]
        observed = np.take_along_axis(decoded_blocks, checks, axis=-1)

        null = _null_decoding_probabilities(phases, candidates, rotations, q_z, q_x)
        candidate_checks = block_bits[:, checks].transpose(1, 2, 0, 3)
        check_errors, check_scores = _per_check_statistics(
            null, candidate_checks, observed, values
        )
        start = attempt * CHECKS_PER_ATTEMPT
        stop = start + CHECKS_PER_ATTEMPT
        errors[:, start:stop] = check_errors.reshape(trials, CHECKS_PER_ATTEMPT)
        scores[:, start:stop] = check_scores.reshape(trials, CHECKS_PER_ATTEMPT)

        attacking = interception_rates > 0
        if attacking.any():
            record_likelihood = _payload_likelihoods(
                rotations[candidates[attacking]],
                forward[attacking],
                returned[attacking],
                q_x,
            )
            active_log_posterior = log_posterior[attacking]
            for block in range(blocks):
                hypothesis_likelihood = record_likelihood[
                    :, block, payload_index[:, block]
                ]
                active_log_posterior += np.log(
                    np.maximum(hypothesis_likelihood, _TINY)
                )
            active_log_posterior -= logsumexp(
                active_log_posterior, axis=-1, keepdims=True
            )
            log_posterior[attacking] = active_log_posterior
            declared = np.exp(log_posterior.max(axis=1)) >= RECOVERY_CONFIDENCE
            interception_rates[declared] = 0.0
        if include_posterior:
            posterior[:, attempt] = np.exp(log_posterior)

    final_key = np.take_along_axis(decoded_blocks, payload, axis=-1).reshape(trials, 4)
    paths = {
        "secret": secret,
        "check_errors": errors,
        "joint_score": scores,
        "final_key_agrees": (final_key == secret_bits[secret]).all(axis=1),
    }
    if include_posterior:
        paths["posterior"] = posterior
        paths["bit_posterior"] = posterior @ secret_bits
    return paths
