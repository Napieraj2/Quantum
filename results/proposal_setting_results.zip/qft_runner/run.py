"""Headless paired QFT proposal sweep using the active exchange and exact prefixes."""
from concurrent.futures import ProcessPoolExecutor
from itertools import product
from pathlib import Path
from math import ceil
import argparse
import time

import numpy as np
import pandas as pd

from archive.qft_pilot.qft_sweep import (
    SWEEP_NOISE_PROFILES,
    EVE_COUNTS,
    EVE_INTERCEPT_RATES,
    EVE_Z_PROBABILITIES,
    EVE_BASIS_REDRAW_RATES,
)
from qft_proposal_exchange import simulate_paths
from quantum_study.qft_study import (
    DETECTORS,
    _declarations,
    _first_alarms,
    _fit_alarm_rule,
)

CHECKS_PER_ATTEMPT = 4
ATTEMPTS = 100
CHECK_LIMIT = ATTEMPTS * CHECKS_PER_ATTEMPT
FIT_PATHS = (1000, 10000)
HOLDOUT_PATHS = 1024
SEED = 20261122
WORK = Path(__file__).resolve().parent

profiles = {}
for label, q_z, q_x in SWEEP_NOISE_PROFILES:
    pair = (round(q_z, 6), round(q_x, 6))
    profiles.setdefault(pair, label)

SETTINGS = list(product(EVE_COUNTS, EVE_INTERCEPT_RATES,
                        EVE_Z_PROBABILITIES, EVE_BASIS_REDRAW_RATES))
NULL = (0, 0.0, None, None)
SCHEDULES = []
for budget in (20, 50, 100):
    SCHEDULES.append(("terminal", budget, (budget,)))
    SCHEDULES.append(("cumulative", budget, tuple(ceil(budget*fraction)
                                                   for fraction in (0.25, 0.5, 1.0))))
SCHEDULES.append(("100 attempts", 400, (100, 200, 400)))


def statistics(paths):
    errors = paths["check_errors"].cumsum(axis=1) / np.arange(1, CHECK_LIMIT + 1)
    joint = paths["joint_score"].cumsum(axis=1)
    return dict(zip(DETECTORS, (errors, joint)))


def outcomes(paths, settings, stats, rules, rng, block_qubits):
    eve_count, intercept_probability, p_z, redraw_probability = settings
    trials = len(paths["secret"])
    if eve_count:
        declaration, guess = _declarations(paths, ATTEMPTS)
        declaration_at = np.minimum(declaration * CHECKS_PER_ATTEMPT, CHECK_LIMIT + 1)
        correct = guess == paths["secret"]
    else:
        declaration_at = np.full(trials, CHECK_LIMIT + 1)
        correct = np.zeros(trials, dtype=bool)
    tie_draws = rng.random(trials)
    rows = []
    for (calibration, policy, budget, looks, detector), rule in rules.items():
        alarm_at = _first_alarms(stats[detector], rule, tie_draws)
        bob_first = (alarm_at <= budget) & (alarm_at <= declaration_at)
        eve_first = (declaration_at <= budget) & (declaration_at < alarm_at)
        had_recovery = eve_first & correct
        stopped = np.minimum(np.minimum(alarm_at, declaration_at), budget)
        blocks_sent = (stopped + block_qubits // 2 - 1) // (block_qubits // 2)
        accepted = (alarm_at > CHECK_LIMIT) & paths["final_key_agrees"]
        rows.append({
            "eve_count": eve_count,
            "intercept_probability": intercept_probability,
            "eve_p_z": p_z,
            "redraw_probability": redraw_probability,
            "calibration_paths": calibration,
            "look_policy": policy,
            "retained_check_budget": budget,
            "looks_in_checks": "/".join(map(str, looks)),
            "detector": detector,
            "trials": trials,
            "alarm_first_count": int(bob_first.sum()),
            "correct_recovery_count": int(had_recovery.sum()),
            "incorrect_declaration_count": int((eve_first & ~correct).sum()),
            "reached_budget_count": int((~(bob_first | eve_first)).sum()),
            "mean_retained_checks": stopped.mean(),
            "mean_transmitted_qubits": (blocks_sent * 2 * block_qubits).mean(),
            "accepted_sessions": int(accepted.sum()) if policy == "100 attempts" else None,
            "exposed_accepted_keys": int((accepted & had_recovery).sum()) if policy == "100 attempts" else None,
        })
    return rows


def run_group(job):
    group_index, qubits, profile, q_z, q_x, attack_trials, smoke = job
    started = time.monotonic()
    target = WORK / ("smoke" if smoke else "full") / f"group_{group_index:02d}.csv"
    if target.exists():
        return f"{target.name} already complete"
    group_seed = np.random.SeedSequence([SEED, group_index])
    calibration_seeds, control_seed, attack_seeds = group_seed.spawn(3)
    fit_sizes = (32, 64) if smoke else FIT_PATHS
    common = dict(qubits=qubits, q_z=q_z, q_x=q_x, attempts=ATTEMPTS)
    rules = {}
    for fit_trials, seed in zip(fit_sizes, calibration_seeds.spawn(len(fit_sizes))):
        paths = simulate_paths(np.random.default_rng(seed), trials=fit_trials,
                               include_posterior=False, **common)
        for detector, fitted in statistics(paths).items():
            for policy, budget, looks in SCHEDULES:
                key = (fit_trials, policy, budget, looks, detector)
                rules[key] = _fit_alarm_rule(fitted, np.array(looks))
    control_rng = np.random.default_rng(control_seed)
    control = simulate_paths(control_rng, trials=64 if smoke else HOLDOUT_PATHS,
                             include_posterior=False, **common)
    rows = outcomes(control, NULL, statistics(control), rules, control_rng, qubits)
    settings_list = (SETTINGS[0], SETTINGS[-1]) if smoke else SETTINGS
    for settings, seed in zip(settings_list, attack_seeds.spawn(len(settings_list))):
        eve_count, intercept, p_z, redraw = settings
        rng = np.random.default_rng(seed)
        paths = simulate_paths(
            rng, trials=attack_trials, intercept_probability=intercept,
            eve_z_probabilities=(p_z,) * eve_count, redraw_probability=redraw, **common
        )
        rows.extend(outcomes(paths, settings, statistics(paths), rules, rng, qubits))
    frame = pd.DataFrame(rows).assign(block_qubits=qubits, noise_profile=profile, q_z=q_z, q_x=q_x)
    temp = target.with_suffix(".tmp")
    frame.to_csv(temp, index=False, float_format="%.9g")
    temp.replace(target)
    return f"{target.name} {qubits}q {profile}: {len(frame):,} rows, {time.monotonic() - started:.1f}s"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trials", type=int, default=256)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    output = WORK / ("smoke" if args.smoke else "full")
    output.mkdir(exist_ok=True)
    jobs = [
        (index, qubits, profile, q_z, q_x, args.trials, args.smoke)
        for index, (qubits, ((q_z, q_x), profile)) in enumerate(product((2, 4), profiles.items()))
        if not args.smoke or index in (1, 11)
    ]
    print(f"Starting {len(jobs)} block/noise groups via {args.workers} workers", flush=True)
    with ProcessPoolExecutor(args.workers) as workers:
        for message in workers.map(run_group, jobs):
            print(message, flush=True)


if __name__ == "__main__":
    main()
